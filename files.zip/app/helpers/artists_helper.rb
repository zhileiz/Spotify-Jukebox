module ArtistsHelper
end
